group10_ppt_last_version: Group 10 presentation power point.
modified_file include motor.c and Part1_Interrupt_bumsw_motor.c files, which are the files we modified.
RTOS_P1 include all of the files of this project.
If one way you open the files couldn't work, then try another way.